clear;clc;%close all
grid_length=20;





% phi_Hs=0.11;
epsilonH1s_grid=linspace(0.95,0.65,grid_length);
% epsilonH1s_grid=0.86;
% phi_Hs_grid=linspace(0.11,0.15,grid_length);
% phi_Hs_grid=linspace(0.05,0.23,grid_length);
phi_Hs_grid=0.11;

global M_;

% var_names={'b_e','b_m','C_m','C_s',  'H_m','H_s','L_m','L_s', 'R_F','R_H'  , 'Vs', 'Vm' 'Y_net', 'phib'};
% var_names_plot={'Business Borrowing','Household Borrowing','Consumption of Borrowers','Consumption of Lenders',...
% 'Housing Owned by Borrowers','Housing Owned by Lenders','Borrowers Labor','Lenders Labor','Business Lending Rate','Household Lending Rate'...
% 'Welfare of Borrowers','Welfare of Savers','Output','Bank Capital'};

 var_names={'b_e','b_m','C_m','C_s', 'def_rate_m','def_rate_B','Vs', 'Vm' 'Y_net_2', 'phib'};
 var_names_plot={'Business Borrowing','Household Borrowing','Consumption of Borrowers','Consumption of Lenders',...
'Household Default Rate','Bank Default Rate',...
 'Welfare of Borrowers','Welfare of Savers','Output','Bank Capital'};


 field_names=cellstr(M_.endo_names);
 index=1;
  for jj=1:length(field_names);
 
if true(strcmp(field_names(jj),var_names(index)))
var_indices(index)=jj;
if index<length(var_names)
    index=index+1;
end

end
      
  end
  %======================================


for jj=1:length(phi_Hs_grid)
    for ee=1:length(epsilonH1s_grid)
% phis=phi_Hs_grid(jj);
phis=0.11;
% phi_Fs=phi_Hs_grid(jj);
phi_Fs=0.11;
% phi_Hs=phi_Hs_grid(jj);
phi_Hs=0.11;

        
    epsilonH1s=epsilonH1s_grid(ee);%epsilonH1s_grid(ee);
%  epsilonH1s=0.86;   
% epsilonF1s=epsilonH1s_grid(ee);
epsilonF1s=0.86;
Cyphi_H=0;
Cyphi_F=0;
LTVHrule=0;
LTVFrule=0;
set_parameter_values_policy( Cyphi_H,Cyphi_F,phi_Hs,phi_Fs,phis,epsilonH1s,epsilonF1s,LTVHrule,LTVFrule);
dynare LTV1_noMeasurement.mod noclearall nolog;
% LTV1_steadystate;
% SS(jj,ee,:)=oo_.steady_state;
SS(jj,ee,:)=oo_.mean;
names=M_.endo_names;



    end
end;


sswelfare=SS(:,:,84).*SS(:,:,9)./(SS(:,:,9)+SS(:,:,10))+ SS(:,:,83).* SS(:,:,10)./(SS(:,:,9)+SS(:,:,10));
adhoc_obj=(SS(:,:,1)+SS(:,:,7)+SS(:,:,109))/3;
adhoc_obj=squeeze(adhoc_obj);
sswelfare=squeeze(sswelfare);
SS=squeeze(SS);
%sswelfare(jj,ee)=ssVs(jj,ee)* ssCs(jj,ee)/(ssCm(jj,ee)+ssCs(jj,ee))+ ssVm(jj,ee)* ssCm(jj,ee)/(ssCm(jj,ee)+ssCs(jj,ee));
% 
% %perc change

% xx=length(sswelfare)-1;
% for tt=1:xx
%     welfare_perc(tt)=100*(log(sswelfare(tt+1))-log(sswelfare(tt)));
%    SS_perc(tt,:)= 100*(log(SS(tt+1,:))-log(SS(tt,:)))
% end



%  figure('Name','change in welfare-level','units','normalized','outerposition',[0 0 1 1]);
% %  plot(epsilonH1s_grid(1:end),(sswelfare),'color','black');
% plot(phi_Hs_grid(1:end),(sswelfare),'color','black');
%  fig = gcf;
% fig.PaperPositionMode = 'auto'
% fig_pos = fig.PaperPosition;
% fig.PaperSize = [fig_pos(3) fig_pos(4)];
% print(fig,'WA1_welflevel','-dpdf');
 
 
%   figure('Name','change in welfare-percentage','units','normalized','outerposition',[0 0 1 1]);
% %  plot(epsilonH1s_grid(2:end),welfare_perc,'color','black');
%  plot(phi_Hs_grid(2:end),welfare_perc,'color','black');
%  fig = gcf;
% fig.PaperPositionMode = 'auto'
% fig_pos = fig.PaperPosition;
% fig.PaperSize = [fig_pos(3) fig_pos(4)];
% print(fig,'WA4_welfperc','-dpdf');
 
figure('Name','change is steady state-level','units','normalized','outerposition',[0 0 1 1]);
for jj=1:length(var_names)
    subplot(4,3,jj);
    plot(epsilonH1s_grid(1:end),squeeze(SS(:,var_indices(jj))),'color','black');
     xlim([epsilonH1s_grid(end) epsilonH1s_grid(1)]);
%  plot(phi_Hs_grid(1:end),squeeze(SS(:,var_indices(jj))),'color','black');
%    xlim([phi_Hs_grid(1) phi_Hs_grid(end)]);
    title(var_names_plot(jj));
end
subplot(4,3,jj+1);
 plot(epsilonH1s_grid(1:end),(sswelfare),'color','black');
 xlim([epsilonH1s_grid(end) epsilonH1s_grid(1)]);
% plot(phi_Hs_grid(1:end),(sswelfare),'color','black');
%  xlim([phi_Hs_grid(1) phi_Hs_grid(end)]);
 title('Household Welfare');



fig = gcf;
fig.PaperPositionMode = 'auto'
fig_pos = fig.PaperPosition;
fig.PaperSize = [fig_pos(3) fig_pos(4)];
print(fig,'WA5_sslevel','-dpdf');
%==============================welfare improvements with a single policy
welfare_max=max(sswelfare);
ind_aux=find(sswelfare==welfare_max);
optimPara_welfare=epsilonH1s_grid(ind_aux)
% optimPara_welfare=phi_Hs_grid(ind_aux)

adhoc_max=max(adhoc_obj);
ind_aux=find(adhoc_obj==adhoc_max);
optimPara_adhoc=epsilonH1s_grid(ind_aux)
% optimPara_adhoc=phi_Hs_grid(ind_aux)



welfare_baseline = -63.078156487529689;
adhoc_baseline=5.773826098382084;


welfare_improvement=100*abs((welfare_max-welfare_baseline)/welfare_baseline)

adhoc_improvement=100*(adhoc_max-adhoc_baseline)/adhoc_baseline














% figure('Name','change is steady state-percentage','units','normalized','outerposition',[0 0 1 1]);
% for jj=1:length(var_names)
%     subplot(5,4,jj);
% %     plot(epsilonH1s_grid(2:end),squeeze(SS_perc(:,var_indices(jj))),'color','black');
%  plot(phi_Hs_grid(2:end),squeeze(SS_perc(:,var_indices(jj))),'color','black');
%     title(var_names(jj));
% end
% fig = gcf;
% fig.PaperPositionMode = 'auto'
% fig_pos = fig.PaperPosition;
% fig.PaperSize = [fig_pos(3) fig_pos(4)];
% print(fig,'WA4_ssperc','-dpdf');



% figure('Name','household welfare','units','normalized','outerposition',[0 0 1 1]);
% surf(sswelfare);
% title('Household Welfare');
% set(gca,'FontSize',30);
% fig = gcf;
% fig.PaperPositionMode = 'auto'
% fig_pos = fig.PaperPosition;
% fig.PaperSize = [fig_pos(3) fig_pos(4)];
% print(fig,'HH_welfare','-dpdf');