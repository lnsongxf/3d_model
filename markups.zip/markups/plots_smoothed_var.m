%============================================
%SMOOTHED SHOCKS
startDate=datenum('01-01-1997');
endDate = datenum('01-12-2016');
T=75;%sample length

Date=linspace(startDate,endDate,T);

load estimation_dataset_quarterly.mat;
figure('Name','Smoothed vs. Actual output growth','units','normalized','outerposition',[0 0 1 1]);

hold on;
plot(Date,oo_.SmoothedVariables.dy_data,'lineWidth',3,'color','black');
hold on;
plot(Date,dy_data(2:2+75-1),'--','color','red','lineWidth',3);
legend('real','model-implied');
  xlim([startDate endDate])
  datetick('x','yy','keeplimits');

set(gca,'FontSize',30);
fig = gcf;
fig.PaperPositionMode = 'auto'
fig_pos = fig.PaperPosition;
fig.PaperSize = [fig_pos(3) fig_pos(4)];
print(fig,'smoothed_dy','-dpdf');

figure;
plot(oo_.SmoothedVariables.A,'color','black','lineWidth',5);
title('A');

figure;
plot(oo_.SmoothedVariables.EJ,'color','black','lineWidth',5);
title('EJ');

figure;
plot(oo_.SmoothedVariables.EK,'color','black','lineWidth',5);
title('EK');

figure;
plot(oo_.SmoothedVariables.EH,'color','black','lineWidth',5);
title('EH');

figure;
plot(oo_.SmoothedVariables.ESe,'color','black','lineWidth',5);
title('ESe');

figure;
plot(oo_.SmoothedVariables.ESm,'color','black','lineWidth',5);
title('ESm');

figure;
plot(oo_.SmoothedVariables.ESF,'color','black','lineWidth',5);
title('ESF');

figure;
plot(oo_.SmoothedVariables.ESH,'color','black','lineWidth',5);
title('ESH');

figure;
plot(oo_.SmoothedVariables.EWe,'color','black','lineWidth',5);
title('EWe');

figure;
plot(oo_.SmoothedVariables.EWb,'color','black','lineWidth',5);
title('EWb');

figure;
plot(oo_.SmoothedVariables.EdH,'color','black','lineWidth',5);
title('EdH');

figure;
plot(oo_.SmoothedVariables.EdK,'color','black','lineWidth',5);
title('EdK');
% 
% %==========================================================
% %KEY IRFS
% figure;
% subplot(4,3,1);
% plot(dy_data_epsiA,'lineWidth',3,'color','black');
% subplot(4,3,2);
% plot(dy_data_epsiH,'lineWidth',3,'color','black');
% subplot(4,3,3);
% plot(dy_data_epsiHd,'lineWidth',3,'color','black');
% subplot(4,3,4);
% plot(dy_data_epsiHk,'lineWidth',3,'color','black');
% subplot(4,3,5);
% plot(dy_data_epsiJ,'lineWidth',3,'color','black');
% subplot(4,3,6);
% plot(dy_data_epsiK,'lineWidth',3,'color','black');
% subplot(4,3,7);
% plot(dy_data_epsiSe,'lineWidth',3,'color','black');
% subplot(4,3,8);
% plot(dy_data_epsiSF,'lineWidth',3,'color','black');
% subplot(4,3,9);
% plot(dy_data_epsiSH,'lineWidth',3,'color','black');
% subplot(4,3,10);
% plot(dy_data_epsiSm,'lineWidth',3,'color','black');
% subplot(4,3,11);
% plot(dy_data_epsiWb,'lineWidth',3,'color','black');
% subplot(4,3,12);
% plot(dy_data_epsiWe,'lineWidth',3,'color','black');
