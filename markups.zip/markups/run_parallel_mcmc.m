clear;clc;close all;
dynare LTV1 parallel conffile='C:\Users\331266\Desktop\markups\MCMC_config.txt'